from django.apps import AppConfig


class GhAuthConfig(AppConfig):
    name = 'gh_auth'
