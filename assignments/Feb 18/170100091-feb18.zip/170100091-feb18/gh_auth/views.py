from django.shortcuts import render

def func(request):
	# if request.user.is_authenticated:
	return render(None, 'blah.html')