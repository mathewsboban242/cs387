
# Example pg_connection_string
# pg_connection_string = """user="foo" password="bar" """
pg_connection_string = """ user=mathews host=localhost port=6300 dbname=postgres """

